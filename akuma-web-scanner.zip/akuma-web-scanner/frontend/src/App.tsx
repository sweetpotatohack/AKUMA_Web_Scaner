/**
 * AKUMA WEB SCANNER - Frontend React App
 * Legendary Cyberpunk Vulnerability Scanner Interface
 * By AKUMA & Феня - The Cyber Gods 🔥💀
 */

import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { Box, Alert, Snackbar } from '@mui/material';

// Components
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import Scans from './pages/Scans';
import ScanDetails from './pages/ScanDetails';
import Vulnerabilities from './pages/Vulnerabilities';
import Reports from './pages/Reports';
import Settings from './pages/Settings';
import Login from './pages/Login';
import LoadingScreen from './components/LoadingScreen';

// Services
import { authService } from './services/authService';
import { websocketService } from './services/websocketService';

// Types
interface User {
  id: number;
  email: string;
  username: string;
}

// Cyberpunk theme
const cyberpunkTheme = createTheme({
  palette: {
    mode: 'dark',
    primary: {
      main: '#00ddff', // Cyber blue
      dark: '#0099cc',
      light: '#33e6ff'
    },
    secondary: {
      main: '#dd00ff', // Cyber purple
      dark: '#aa00cc',
      light: '#e633ff'
    },
    error: {
      main: '#ff0066', // Cyber red
      dark: '#cc0044',
      light: '#ff3388'
    },
    success: {
      main: '#00ff66', // Cyber green
      dark: '#00cc44',
      light: '#33ff88'
    },
    warning: {
      main: '#ff6600', // Cyber orange
      dark: '#cc4400',
      light: '#ff8833'
    },
    background: {
      default: '#0a0a0a',
      paper: '#1a1a1a'
    },
    text: {
      primary: '#ffffff',
      secondary: '#cccccc'
    }
  },
  typography: {
    fontFamily: '"Courier New", "Roboto Mono", monospace',
    h1: {
      fontWeight: 700,
      fontSize: '2.5rem',
      textShadow: '0 0 20px #00ddff'
    },
    h2: {
      fontWeight: 600,
      fontSize: '2rem',
      textShadow: '0 0 15px #dd00ff'
    },
    h3: {
      fontWeight: 600,
      fontSize: '1.5rem',
      textShadow: '0 0 10px #00ff66'
    }
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          textTransform: 'none',
          fontFamily: '"Courier New", monospace',
          fontWeight: 600,
          borderRadius: 8,
          boxShadow: '0 0 10px rgba(0, 221, 255, 0.3)',
          transition: 'all 0.3s ease',
          '&:hover': {
            boxShadow: '0 0 20px rgba(0, 221, 255, 0.6)',
            transform: 'translateY(-2px)'
          }
        }
      }
    },
    MuiCard: {
      styleOverrides: {
        root: {
          backgroundColor: '#1a1a1a',
          border: '1px solid #333333',
          borderRadius: 12,
          boxShadow: '0 4px 20px rgba(0, 0, 0, 0.5)',
          transition: 'all 0.3s ease',
          '&:hover': {
            border: '1px solid #00ddff',
            boxShadow: '0 8px 30px rgba(0, 221, 255, 0.2)'
          }
        }
      }
    },
    MuiAppBar: {
      styleOverrides: {
        root: {
          backgroundColor: '#111111',
          borderBottom: '2px solid #00ddff',
          boxShadow: '0 0 20px rgba(0, 221, 255, 0.3)'
        }
      }
    },
    MuiDrawer: {
      styleOverrides: {
        paper: {
          backgroundColor: '#111111',
          borderRight: '2px solid #dd00ff',
          boxShadow: '0 0 20px rgba(221, 0, 255, 0.3)'
        }
      }
    }
  }
});

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [notification, setNotification] = useState<{
    open: boolean;
    message: string;
    severity: 'success' | 'error' | 'warning' | 'info';
  }>({
    open: false,
    message: '',
    severity: 'info'
  });

  useEffect(() => {
    checkAuth();
    initializeWebSocket();
  }, []);

  const checkAuth = async () => {
    try {
      const token = localStorage.getItem('akuma_token');
      if (token) {
        // Validate token with backend
        const userData = await authService.getCurrentUser();
        setUser(userData);
      }
    } catch (error) {
      console.error('Auth check failed:', error);
      localStorage.removeItem('akuma_token');
    } finally {
      setLoading(false);
    }
  };

  const initializeWebSocket = () => {
    if (user) {
      websocketService.connect();
      
      // Subscribe to notifications
      websocketService.onMessage((message) => {
        if (message.type === 'scan_completed' || message.type === 'scan_failed') {
          showNotification(message.message, message.type === 'scan_completed' ? 'success' : 'error');
        }
      });
    }
  };

  const handleLogin = async (email: string, password: string) => {
    try {
      const response = await authService.login(email, password);
      localStorage.setItem('akuma_token', response.access_token);
      setUser(response.user);
      showNotification('🔥 Login successful! Welcome to the matrix!', 'success');
      return true;
    } catch (error: any) {
      showNotification(error.response?.data?.detail || 'Login failed', 'error');
      return false;
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('akuma_token');
    setUser(null);
    websocketService.disconnect();
    showNotification('👋 Logout successful!', 'info');
  };

  const showNotification = (message: string, severity: 'success' | 'error' | 'warning' | 'info') => {
    setNotification({ open: true, message, severity });
  };

  const closeNotification = () => {
    setNotification({ ...notification, open: false });
  };

  if (loading) {
    return <LoadingScreen />;
  }

  if (!user) {
    return (
      <ThemeProvider theme={cyberpunkTheme}>
        <CssBaseline />
        <Login onLogin={handleLogin} />
      </ThemeProvider>
    );
  }

  return (
    <ThemeProvider theme={cyberpunkTheme}>
      <CssBaseline />
      <Router>
        <Box sx={{ display: 'flex', minHeight: '100vh' }}>
          {/* Header */}
          <Header 
            user={user}
            onLogout={handleLogout}
            onMenuClick={() => setSidebarOpen(!sidebarOpen)}
          />
          
          {/* Sidebar */}
          <Sidebar 
            open={sidebarOpen}
            onClose={() => setSidebarOpen(false)}
          />
          
          {/* Main Content */}
          <Box
            component="main"
            sx={{
              flexGrow: 1,
              padding: 3,
              marginTop: '64px',
              marginLeft: sidebarOpen ? '240px' : '0px',
              transition: 'margin-left 0.3s ease',
              background: 'linear-gradient(135deg, #0a0a0a 0%, #1a0a1a 100%)',
              minHeight: 'calc(100vh - 64px)'
            }}
          >
            <Routes>
              <Route path="/" element={<Navigate to="/dashboard" replace />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/scans" element={<Scans />} />
              <Route path="/scans/:id" element={<ScanDetails />} />
              <Route path="/vulnerabilities" element={<Vulnerabilities />} />
              <Route path="/reports" element={<Reports />} />
              <Route path="/settings" element={<Settings />} />
              <Route path="*" element={<Navigate to="/dashboard" replace />} />
            </Routes>
          </Box>
          
          {/* Notifications */}
          <Snackbar
            open={notification.open}
            autoHideDuration={6000}
            onClose={closeNotification}
            anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
          >
            <Alert 
              onClose={closeNotification} 
              severity={notification.severity}
              sx={{ 
                width: '100%',
                fontFamily: '"Courier New", monospace',
                '& .MuiAlert-icon': {
                  fontSize: '1.5rem'
                }
              }}
            >
              {notification.message}
            </Alert>
          </Snackbar>
        </Box>
      </Router>
    </ThemeProvider>
  );
};

export default App;

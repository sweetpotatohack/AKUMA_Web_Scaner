/**
 * AKUMA WEB SCANNER - Dashboard Page
 * Cyberpunk Dashboard with Statistics and Charts
 * By AKUMA & Феня - The Cyber Gods 🔥💀
 */

import React, { useState, useEffect } from 'react';
import {
  Grid,
  Card,
  CardContent,
  Typography,
  Box,
  Button,
  LinearProgress,
  IconButton,
  Tooltip,
  Avatar,
  Chip,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  ListItemSecondaryAction
} from '@mui/material';
import {
  Dashboard as DashboardIcon,
  Security,
  BugReport,
  Speed,
  PlayArrow,
  Stop,
  Refresh,
  TrendingUp,
  Warning,
  CheckCircle,
  Error,
  Info
} from '@mui/icons-material';
import { Line, Doughnut, Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip as ChartTooltip,
  Legend,
  ArcElement,
  BarElement
} from 'chart.js';

// Services
import { apiService } from '../services/apiService';

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  ChartTooltip,
  Legend,
  ArcElement,
  BarElement
);

interface DashboardStats {
  total_scans: number;
  completed_scans: number;
  running_scans: number;
  total_vulnerabilities: number;
  critical_vulnerabilities: number;
  recent_scans: Array<{
    id: number;
    name: string;
    status: string;
    created_at: string;
    targets_count: number;
  }>;
}

const Dashboard: React.FC = () => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardStats();
    
    // Auto-refresh every 30 seconds
    const interval = setInterval(loadDashboardStats, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadDashboardStats = async () => {
    try {
      const data = await apiService.getDashboardStats();
      setStats(data);
    } catch (error) {
      console.error('Failed to load dashboard stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return '#00ff66';
      case 'running': return '#00ddff';
      case 'failed': return '#ff0066';
      case 'pending': return '#ff6600';
      default: return '#cccccc';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle />;
      case 'running': return <PlayArrow />;
      case 'failed': return <Error />;
      case 'pending': return <Info />;
      default: return <Info />;
    }
  };

  // Chart data for vulnerability distribution
  const vulnerabilityChartData = {
    labels: ['Critical', 'High', 'Medium', 'Low'],
    datasets: [
      {
        data: stats ? [
          stats.critical_vulnerabilities,
          Math.floor(stats.total_vulnerabilities * 0.3),
          Math.floor(stats.total_vulnerabilities * 0.4),
          Math.floor(stats.total_vulnerabilities * 0.2)
        ] : [0, 0, 0, 0],
        backgroundColor: ['#ff0066', '#ff6600', '#ffff00', '#00ff66'],
        borderColor: ['#ff0066', '#ff6600', '#ffff00', '#00ff66'],
        borderWidth: 2,
        hoverOffset: 4
      }
    ]
  };

  // Chart options with cyberpunk styling
  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'bottom' as const,
        labels: {
          color: '#ffffff',
          font: {
            family: 'Courier New',
            size: 12
          }
        }
      }
    },
    scales: {
      x: {
        ticks: { color: '#ffffff' },
        grid: { color: 'rgba(255, 255, 255, 0.1)' }
      },
      y: {
        ticks: { color: '#ffffff' },
        grid: { color: 'rgba(255, 255, 255, 0.1)' }
      }
    }
  };

  if (loading) {
    return (
      <Box sx={{ padding: 3 }}>
        <Typography variant="h4" gutterBottom>
          🔥 Loading AKUMA Dashboard...
        </Typography>
        <LinearProgress sx={{ marginTop: 2 }} />
      </Box>
    );
  }

  return (
    <Box sx={{ padding: 3 }}>
      {/* Header */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 3 }}>
        <Typography 
          variant="h3" 
          sx={{ 
            display: 'flex', 
            alignItems: 'center', 
            gap: 2,
            background: 'linear-gradient(45deg, #00ddff, #dd00ff)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent'
          }}
        >
          <DashboardIcon sx={{ fontSize: '3rem', color: '#00ddff' }} />
          🔥 AKUMA DASHBOARD 🔥
        </Typography>
        
        <Tooltip title="Refresh Data">
          <IconButton 
            onClick={loadDashboardStats}
            sx={{ 
              color: '#00ddff',
              '&:hover': { 
                color: '#ffffff',
                boxShadow: '0 0 20px #00ddff'
              }
            }}
          >
            <Refresh />
          </IconButton>
        </Tooltip>
      </Box>

      {/* Statistics Cards */}
      <Grid container spacing={3} sx={{ marginBottom: 4 }}>
        {/* Total Scans */}
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ 
            background: 'linear-gradient(135deg, #1a1a1a, #2a1a2a)',
            border: '2px solid #00ddff',
            '&:hover': { boxShadow: '0 0 30px rgba(0, 221, 255, 0.4)' }
          }}>
            <CardContent sx={{ textAlign: 'center' }}>
              <Security sx={{ fontSize: '3rem', color: '#00ddff', marginBottom: 1 }} />
              <Typography variant="h4" sx={{ color: '#00ddff', fontWeight: 'bold' }}>
                {stats?.total_scans || 0}
              </Typography>
              <Typography variant="body1" sx={{ color: '#cccccc' }}>
                Total Scans
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        {/* Running Scans */}
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ 
            background: 'linear-gradient(135deg, #1a1a1a, #1a2a1a)',
            border: '2px solid #00ff66',
            '&:hover': { boxShadow: '0 0 30px rgba(0, 255, 102, 0.4)' }
          }}>
            <CardContent sx={{ textAlign: 'center' }}>
              <Speed sx={{ fontSize: '3rem', color: '#00ff66', marginBottom: 1 }} />
              <Typography variant="h4" sx={{ color: '#00ff66', fontWeight: 'bold' }}>
                {stats?.running_scans || 0}
              </Typography>
              <Typography variant="body1" sx={{ color: '#cccccc' }}>
                Running Scans
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        {/* Total Vulnerabilities */}
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ 
            background: 'linear-gradient(135deg, #1a1a1a, #2a1a1a)',
            border: '2px solid #ff6600',
            '&:hover': { boxShadow: '0 0 30px rgba(255, 102, 0, 0.4)' }
          }}>
            <CardContent sx={{ textAlign: 'center' }}>
              <BugReport sx={{ fontSize: '3rem', color: '#ff6600', marginBottom: 1 }} />
              <Typography variant="h4" sx={{ color: '#ff6600', fontWeight: 'bold' }}>
                {stats?.total_vulnerabilities || 0}
              </Typography>
              <Typography variant="body1" sx={{ color: '#cccccc' }}>
                Total Vulnerabilities
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        {/* Critical Vulnerabilities */}
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ 
            background: 'linear-gradient(135deg, #1a1a1a, #2a1a1a)',
            border: '2px solid #ff0066',
            '&:hover': { boxShadow: '0 0 30px rgba(255, 0, 102, 0.4)' }
          }}>
            <CardContent sx={{ textAlign: 'center' }}>
              <Warning sx={{ fontSize: '3rem', color: '#ff0066', marginBottom: 1 }} />
              <Typography variant="h4" sx={{ color: '#ff0066', fontWeight: 'bold' }}>
                {stats?.critical_vulnerabilities || 0}
              </Typography>
              <Typography variant="body1" sx={{ color: '#cccccc' }}>
                Critical Vulns
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Charts and Recent Activity */}
      <Grid container spacing={3}>
        {/* Vulnerability Distribution Chart */}
        <Grid item xs={12} md={6}>
          <Card sx={{ height: '400px' }}>
            <CardContent>
              <Typography variant="h6" sx={{ marginBottom: 2, color: '#dd00ff' }}>
                🎯 Vulnerability Distribution
              </Typography>
              <Box sx={{ height: '300px', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                <Doughnut 
                  data={vulnerabilityChartData}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                      legend: {
                        position: 'bottom',
                        labels: {
                          color: '#ffffff',
                          font: { family: 'Courier New', size: 10 }
                        }
                      }
                    }
                  }}
                />
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Recent Scans */}
        <Grid item xs={12} md={6}>
          <Card sx={{ height: '400px' }}>
            <CardContent>
              <Typography variant="h6" sx={{ marginBottom: 2, color: '#00ff66' }}>
                🚀 Recent Scans
              </Typography>
              <Box sx={{ maxHeight: '320px', overflow: 'auto' }}>
                <List>
                  {stats?.recent_scans?.map((scan) => (
                    <ListItem key={scan.id} sx={{ 
                      borderRadius: 2, 
                      marginBottom: 1,
                      background: 'rgba(255, 255, 255, 0.05)',
                      '&:hover': { background: 'rgba(0, 221, 255, 0.1)' }
                    }}>
                      <ListItemAvatar>
                        <Avatar sx={{ 
                          backgroundColor: getStatusColor(scan.status),
                          color: '#000000'
                        }}>
                          {getStatusIcon(scan.status)}
                        </Avatar>
                      </ListItemAvatar>
                      <ListItemText
                        primary={
                          <Typography variant="body1" sx={{ fontWeight: 'bold' }}>
                            {scan.name}
                          </Typography>
                        }
                        secondary={
                          <Box>
                            <Typography variant="body2" sx={{ color: '#cccccc' }}>
                              {scan.targets_count} targets
                            </Typography>
                            <Typography variant="caption" sx={{ color: '#999999' }}>
                              {new Date(scan.created_at).toLocaleDateString()}
                            </Typography>
                          </Box>
                        }
                      />
                      <ListItemSecondaryAction>
                        <Chip 
                          label={scan.status.toUpperCase()}
                          size="small"
                          sx={{ 
                            backgroundColor: getStatusColor(scan.status),
                            color: '#000000',
                            fontWeight: 'bold',
                            fontFamily: 'Courier New'
                          }}
                        />
                      </ListItemSecondaryAction>
                    </ListItem>
                  ))}
                </List>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Quick Actions */}
      <Box sx={{ marginTop: 4, textAlign: 'center' }}>
        <Typography variant="h5" sx={{ marginBottom: 2, color: '#dd00ff' }}>
          💀 Quick Actions
        </Typography>
        <Box sx={{ display: 'flex', gap: 2, justifyContent: 'center', flexWrap: 'wrap' }}>
          <Button
            variant="contained"
            size="large"
            startIcon={<PlayArrow />}
            sx={{ 
              background: 'linear-gradient(45deg, #00ddff, #0099cc)',
              '&:hover': { 
                background: 'linear-gradient(45deg, #0099cc, #00ddff)',
                transform: 'scale(1.05)'
              }
            }}
            onClick={() => window.location.href = '/scans'}
          >
            🚀 New Scan
          </Button>
          
          <Button
            variant="contained"
            size="large"
            startIcon={<BugReport />}
            sx={{ 
              background: 'linear-gradient(45deg, #ff6600, #cc4400)',
              '&:hover': { 
                background: 'linear-gradient(45deg, #cc4400, #ff6600)',
                transform: 'scale(1.05)'
              }
            }}
            onClick={() => window.location.href = '/vulnerabilities'}
          >
            🔍 View Vulnerabilities
          </Button>
          
          <Button
            variant="contained"
            size="large"
            startIcon={<TrendingUp />}
            sx={{ 
              background: 'linear-gradient(45deg, #dd00ff, #aa00cc)',
              '&:hover': { 
                background: 'linear-gradient(45deg, #aa00cc, #dd00ff)',
                transform: 'scale(1.05)'
              }
            }}
            onClick={() => window.location.href = '/reports'}
          >
            📊 Generate Report
          </Button>
        </Box>
      </Box>
    </Box>
  );
};

export default Dashboard;
